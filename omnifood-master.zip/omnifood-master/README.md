# Omnifood :hamburger: :fries: :pizza:
Online food delivery service website prototype. This project was made by referencing online tutorial in udemy "Build Responsive Real World Websites with HTML5 and CSS3" by Jonas Schmedtmann.

---

![frontpage](https://i.imgur.com/LudB51c.png)

---
